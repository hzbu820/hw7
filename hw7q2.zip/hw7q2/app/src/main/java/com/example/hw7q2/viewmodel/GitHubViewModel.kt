package com.example.hw7q2.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw7q2.data.repository.GitHubRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GitHubViewModel(
    private val repository: GitHubRepository = GitHubRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(GitHubUiState())
    val uiState: StateFlow<GitHubUiState> = _uiState.asStateFlow()

    fun searchRepositories(username: String) {
        if (username.isBlank()) return
        
        _uiState.update { currentState ->
            currentState.copy(
                isLoading = true,
                isInitialLoad = true,
                error = null,
                repos = emptyList(),
                currentPage = 1,
                username = username
            )
        }
        
        fetchRepositories(username, 1)
    }

    fun loadNextPage() {
        val currentState = _uiState.value
        
        if (currentState.isLoading || !currentState.hasNextPage) return
        
        _uiState.update { it.copy(isLoading = true, isInitialLoad = false) }
        
        fetchRepositories(currentState.username, currentState.currentPage + 1)
    }

    private fun fetchRepositories(username: String, page: Int) {
        viewModelScope.launch {
            repository.getUserRepositories(username, page).collect { result ->
                result.fold(
                    onSuccess = { (repos, hasNextPage) ->
                        val currentRepos = if (page == 1) {
                            repos
                        } else {
                            _uiState.value.repos + repos
                        }
                        
                        _uiState.update { currentState ->
                            currentState.copy(
                                isLoading = false,
                                isInitialLoad = false,
                                repos = currentRepos,
                                error = null,
                                hasNextPage = hasNextPage,
                                currentPage = page
                            )
                        }
                    },
                    onFailure = { error ->
                        _uiState.update { currentState ->
                            currentState.copy(
                                isLoading = false,
                                error = error.message ?: "An unknown error occurred"
                            )
                        }
                    }
                )
            }
        }
    }
} 
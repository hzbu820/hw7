package com.example.hw7q2.data.repository

import com.example.hw7q2.data.model.GitHubRepo
import com.example.hw7q2.data.network.GitHubApiService
import com.example.hw7q2.data.network.NetworkModule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException

class GitHubRepository(
    private val gitHubApiService: GitHubApiService = NetworkModule.gitHubApiService
) {
    fun getUserRepositories(username: String, page: Int): Flow<Result<Pair<List<GitHubRepo>, Boolean>>> = flow {
        try {
            val response = gitHubApiService.getUserRepositories(username, page = page)
            
            if (response.isSuccessful) {
                val repos = response.body() ?: emptyList()
                val hasNextPage = NetworkModule.hasNextPage(response)
                emit(Result.success(Pair(repos, hasNextPage)))
            } else {
                emit(Result.failure(HttpException(response)))
            }
        } catch (e: IOException) {
            emit(Result.failure(e))
        } catch (e: HttpException) {
            emit(Result.failure(e))
        }
    }
} 
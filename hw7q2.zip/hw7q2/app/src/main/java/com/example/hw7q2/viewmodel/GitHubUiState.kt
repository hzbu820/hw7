package com.example.hw7q2.viewmodel

import com.example.hw7q2.data.model.GitHubRepo

data class GitHubUiState(
    val isLoading: Boolean = false,
    val isInitialLoad: Boolean = true,
    val repos: List<GitHubRepo> = emptyList(),
    val error: String? = null,
    val hasNextPage: Boolean = false,
    val currentPage: Int = 1,
    val username: String = ""
) 
package com.example.hw7q2.data.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {
    private const val BASE_URL = "https://api.github.com/"
    
    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
    
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }
    
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
    
    val gitHubApiService: GitHubApiService = retrofit.create(GitHubApiService::class.java)
    
    // Helper function to check if there are more pages from the Link header
    fun hasNextPage(response: Response<*>): Boolean {
        val linkHeader = response.headers()["Link"] ?: return false
        return linkHeader.contains("rel=\"next\"")
    }
    
    // Helper function to extract next page number from Link header
    fun getNextPageNumber(response: Response<*>): Int? {
        val linkHeader = response.headers()["Link"] ?: return null
        // Example Link header: <https://api.github.com/user/repos?page=2>; rel="next"
        val nextLink = linkHeader.split(",").find { it.contains("rel=\"next\"") } ?: return null
        val regex = Regex("page=(\\d+)")
        val matchResult = regex.find(nextLink) ?: return null
        return matchResult.groupValues[1].toIntOrNull()
    }
} 
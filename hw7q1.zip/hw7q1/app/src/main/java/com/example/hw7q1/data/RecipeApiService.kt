package com.example.hw7q1.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface RecipeApiService {
    @GET("api/json/v1/1/search.php")
    suspend fun searchRecipes(@Query("s") query: String): MealResponse
    
    companion object {
        private const val BASE_URL = "https://www.themealdb.com/"
        
        fun create(): RecipeApiService {
            val logger = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            
            val client = OkHttpClient.Builder()
                .addInterceptor(logger)
                .build()
                
            val moshi = Moshi.Builder()
                .add(KotlinJsonAdapterFactory())
                .build()
                
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(RecipeApiService::class.java)
        }
    }
} 
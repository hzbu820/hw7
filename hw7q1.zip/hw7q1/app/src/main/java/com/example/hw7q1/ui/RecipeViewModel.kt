package com.example.hw7q1.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw7q1.data.Meal
import com.example.hw7q1.data.RecipeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class RecipeViewModel : ViewModel() {
    private val repository = RecipeRepository()
    
    private val _uiState = MutableStateFlow(RecipeUiState())
    val uiState: StateFlow<RecipeUiState> = _uiState.asStateFlow()
    
    fun searchRecipes(query: String) {
        if (query.isBlank()) return
        
        _uiState.update { it.copy(isLoading = true, error = null) }
        
        viewModelScope.launch {
            repository.searchRecipes(query)
                .onSuccess { recipes ->
                    _uiState.update { 
                        it.copy(
                            recipes = recipes,
                            isLoading = false,
                            error = if (recipes.isEmpty()) "No recipes found" else null
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update { 
                        it.copy(
                            isLoading = false,
                            error = error.message ?: "Unknown error occurred"
                        )
                    }
                }
        }
    }
    
    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }
}

data class RecipeUiState(
    val searchQuery: String = "",
    val recipes: List<Meal> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
) 
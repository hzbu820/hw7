package com.example.hw7q1.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class RecipeRepository {
    private val recipeApiService = RecipeApiService.create()
    
    suspend fun searchRecipes(query: String): Result<List<Meal>> {
        return withContext(Dispatchers.IO) {
            try {
                val response = recipeApiService.searchRecipes(query)
                if (response.meals != null) {
                    Result.success(response.meals)
                } else {
                    Result.success(emptyList())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }
} 
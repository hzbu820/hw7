package com.example.hw7q1.data

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MealResponse(
    @Json(name = "meals") val meals: List<Meal>?
)

@JsonClass(generateAdapter = true)
data class Meal(
    @Json(name = "idMeal") val id: String,
    @Json(name = "strMeal") val name: String,
    @Json(name = "strCategory") val category: String?,
    @Json(name = "strArea") val area: String?,
    @Json(name = "strInstructions") val instructions: String?,
    @Json(name = "strMealThumb") val imageUrl: String?,
    @Json(name = "strTags") val tags: String?,
    @Json(name = "strYoutube") val youtubeUrl: String?,
    
    // Ingredients and Measures
    @Json(name = "strIngredient1") val ingredient1: String?,
    @Json(name = "strIngredient2") val ingredient2: String?,
    @Json(name = "strIngredient3") val ingredient3: String?,
    @Json(name = "strIngredient4") val ingredient4: String?,
    @Json(name = "strIngredient5") val ingredient5: String?,
    @Json(name = "strIngredient6") val ingredient6: String?,
    @Json(name = "strIngredient7") val ingredient7: String?,
    @Json(name = "strIngredient8") val ingredient8: String?,
    
    @Json(name = "strMeasure1") val measure1: String?,
    @Json(name = "strMeasure2") val measure2: String?,
    @Json(name = "strMeasure3") val measure3: String?,
    @Json(name = "strMeasure4") val measure4: String?,
    @Json(name = "strMeasure5") val measure5: String?,
    @Json(name = "strMeasure6") val measure6: String?,
    @Json(name = "strMeasure7") val measure7: String?,
    @Json(name = "strMeasure8") val measure8: String?
) {
    // Helper function to get a list of ingredients with their measures
    fun getIngredientsWithMeasures(): List<String> {
        val ingredientsWithMeasures = mutableListOf<String>()
        
        addIngredientIfNotEmpty(ingredient1, measure1, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient2, measure2, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient3, measure3, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient4, measure4, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient5, measure5, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient6, measure6, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient7, measure7, ingredientsWithMeasures)
        addIngredientIfNotEmpty(ingredient8, measure8, ingredientsWithMeasures)
        
        return ingredientsWithMeasures
    }
    
    private fun addIngredientIfNotEmpty(ingredient: String?, measure: String?, list: MutableList<String>) {
        if (!ingredient.isNullOrBlank() && ingredient != "null") {
            val measureText = if (!measure.isNullOrBlank() && measure != "null") measure else ""
            list.add("$measureText $ingredient".trim())
        }
    }
} 